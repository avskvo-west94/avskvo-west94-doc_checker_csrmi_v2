using System.Windows;

namespace DocumentChecker
{
    public partial class App : Application
    {
    }
}
